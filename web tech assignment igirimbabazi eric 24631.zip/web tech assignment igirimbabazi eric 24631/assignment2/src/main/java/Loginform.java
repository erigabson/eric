import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class Loginform extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean isValidLogin = checkLoginCredentials(username, password);


        response.setContentType("text/html");

        PrintWriter out = response.getWriter();


        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Login Result</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Login Result</h2>");

        if (isValidLogin) {
            out.println("<p>Login successful. Welcome, " + username + "!</p>");
        } else {
            out.println("<p>Invalid login credentials. Please try again.</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }

    private boolean checkLoginCredentials(String username, String password) {
        // Replace this with your actual login logic (e.g., querying a database)
        // For simplicity, this example considers a hardcoded username and password.
        return "admin".equals(username) && "password123".equals(password);
    }
}
